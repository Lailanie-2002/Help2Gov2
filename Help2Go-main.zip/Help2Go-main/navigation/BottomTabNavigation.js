import { View, Text } from 'react-native'
import React from 'react'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { COLORS, FONTS } from '../constants'
import { Chats, Contacts, More } from '../screens'
import { FontAwesome, Feather, Ionicons } from '@expo/vector-icons'
import Post from '../StoreText/StorePost'

const Tab = createBottomTabNavigator()

const BottomTabNavigation = () => {
    return (
        <Tab.Navigator
            screenOptions={{
                tabBarShowLabel: false,
                headerShown: false,
                tabBarHideOnKeyboard: true,
                tabBarStyle: {
                    position: 'absolute',
                    backgroundColor: COLORS.white,
                    bottom: 0,
                    right: 0,
                    left: 0,
                    elevation: 0,
                    height: 60,
                },
            }}
        >
            <Tab.Screen
                name="Post"
                component={Post}
                options={{
                    tabBarIcon: ({ focused }) => {
                        return (
                            <View
                                style={{
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                }}
                            >
                                {focused ? (
                                    <>
                                        <Text
                                            style={{
                                                ...FONTS.body3,
                                                color: COLORS.blue,
                                            }}
                                        >
                                            Posts
                                        </Text>
                                        <FontAwesome
                                            name="circle"
                                            size={8}
                                            color={COLORS.blue}
                                        />
                                    </>
                                ) : (
                                    <Feather
                                        name="layout"
                                        size={24}
                                        color={COLORS.blue}
                                    />
                                )}
                            </View>
                        )
                    },
                }}
            />

            <Tab.Screen
                name="Chats"
                component={Chats}
                options={{
                    tabBarIcon: ({ focused }) => {
                        return (
                            <View
                                style={{
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                }}
                            >
                                {focused ? (
                                    <>
                                        <Text
                                            style={{
                                                ...FONTS.body3,
                                                color: COLORS.blue,
                                            }}
                                        >
                                            Chats
                                        </Text>
                                        <FontAwesome
                                            name="circle"
                                            size={8}
                                            color={COLORS.blue}
                                        />
                                    </>
                                ) : (
                                    <Ionicons
                                        name="chatbubble-outline"
                                        size={24}
                                        color={COLORS.blue}
                                    />
                                )}
                            </View>
                        )
                    },
                }}
            />

            <Tab.Screen
                name="More"
                component={More}
                options={{
                    tabBarIcon: ({ focused }) => {
                        return (
                            <View
                                style={{
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                }}
                            >
                                {focused ? (
                                    <>
                                        <Text
                                            style={{
                                                ...FONTS.body3,
                                                color: COLORS.blue,
                                            }}
                                        >
                                            More
                                        </Text>
                                        <FontAwesome
                                            name="circle"
                                            size={8}
                                            color={COLORS.blue}
                                        />
                                    </>
                                ) : (
                                    <Feather
                                        name="more-horizontal"
                                        size={24}
                                        color={COLORS.blue}
                                    />
                                )}
                            </View>
                        )
                    },
                }}
            />
        </Tab.Navigator>
    )
}

export default BottomTabNavigation
