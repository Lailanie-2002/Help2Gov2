import React, { useState } from 'react';
import { View, TextInput, Button, Text, ScrollView, TouchableOpacity } from 'react-native';
import { FONTS, COLORS } from '../constants'
import { MaterialCommunityIcons, AntDesign, Ionicons } from '@expo/vector-icons'

const App = () => {
  const [postText, setPostText] = useState('');
  const [posts, setPosts] = useState([]);

  const handlePost = () => {
    // Simulate posting data locally (for UI purposes)
    const newPost = { id: Date.now(), text: postText };
    
    // Move the latest post to the top
    setPosts((prevPosts) => [newPost, ...prevPosts]);

    setPostText('');
  };

  const handleDelete = (postId) => {
    setPosts((prevPosts) => prevPosts.filter(post => post.id !== postId));
  };

  return (
    <View>
        <Text style={{ ...FONTS.h3, justifyContent: 'space-between',
                            alignItems: 'center',
                            marginHorizontal: 22,
                            marginTop: 51, }}>Job Posting</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
      <TextInput
        placeholder="What's on your mind?"
        value={postText}
        onChangeText={setPostText}
        style={{ padding: 10, borderColor: COLORS.gray, borderWidth: 1, borderRadius: 10, width: '75%', marginLeft: '5%', marginTop: 22 }}
      />
      <TouchableOpacity title="Post"
        onPress={handlePost}
        style={{
            marginHorizontal: 12,
            marginTop: 22,
            borderRadius: 15,
          width: 55,
          marginRight: '6%',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: COLORS.yellow
        }}>
        <Text style={{color: COLORS.white}}>Post</Text>
      </TouchableOpacity>
        </View>
      <ScrollView>
        {posts.map((post) => (
          <View key={post.id} style={{marginTop: 5, marginLeft: 20, marginRight: 20, padding:15, borderBottomWidth: 1, borderColor: COLORS.gray}}>
            <Text style={{ color: COLORS.gray }}>posted 1 min ago</Text>
            <View style={{ flexDirection: 'row' }}>
            <Text style={{ fontSize: 32, fontWeight: '800', maxWidth: '55%', width: '60%' }}>{post.text}</Text>
            <TouchableOpacity style={{ marginLeft: 90 }}><Ionicons name="heart-circle-sharp" size={28} color="black" /></TouchableOpacity>
            <TouchableOpacity><Ionicons name="heart-dislike-circle-sharp" size={28} color="black" /></TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => handleDelete(post.id)}>
              <Text style={{ color: 'red' }}>Delete</Text>
            </TouchableOpacity>
          </View>

        ))}

        <View>
        <View style={{marginTop: 5, marginLeft: 20, marginRight: 20, padding:15, borderBottomWidth: 1, borderColor: COLORS.gray}}>
            <Text style={{ color: COLORS.gray }}>posted 1 min ago</Text>
            <View style={{ flexDirection: 'row' }}>
            <Text style={{ fontSize: 18, fontWeight: '800', maxWidth: '55%', width: '60%' }}>Quantum Dynamics Innovations</Text>
            <TouchableOpacity style={{ marginLeft: 90 }}><Ionicons name="heart-circle-sharp" size={28} color="black" /></TouchableOpacity>
            <TouchableOpacity><Ionicons name="heart-dislike-circle-sharp" size={28} color="black" /></TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => handleDelete(post.id)}>
              <Text style={{ color: 'red' }}>Delete</Text>
            </TouchableOpacity>
          </View>

        </View>

        <View>
        <View style={{marginTop: 5, marginLeft: 20, marginRight: 20, padding:15, borderBottomWidth: 1, borderColor: COLORS.gray}}>
            <Text style={{ color: COLORS.gray }}>posted 1 min ago</Text>
            <View style={{ flexDirection: 'row' }}>
            <Text style={{ fontSize: 18, fontWeight: '800', maxWidth: '55%', width: '60%' }}>Stellar Horizon Solutions</Text>
            <TouchableOpacity style={{ marginLeft: 90 }}><Ionicons name="heart-circle-sharp" size={28} color="black" /></TouchableOpacity>
            <TouchableOpacity><Ionicons name="heart-dislike-circle-sharp" size={28} color="black" /></TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => handleDelete(post.id)}>
              <Text style={{ color: 'red' }}>Delete</Text>
            </TouchableOpacity>
          </View>

        </View>

        <View>
        <View style={{marginTop: 5, marginLeft: 20, marginRight: 20, padding:15, borderBottomWidth: 1, borderColor: COLORS.gray}}>
            <Text style={{ color: COLORS.gray }}>posted 1 min ago</Text>
            <View style={{ flexDirection: 'row' }}>
            <Text style={{ fontSize: 18, fontWeight: '800', maxWidth: '55%', width: '60%' }}>Nexus Synergy Technologies</Text>
            <TouchableOpacity style={{ marginLeft: 90 }}><Ionicons name="heart-circle-sharp" size={28} color="black" /></TouchableOpacity>
            <TouchableOpacity><Ionicons name="heart-dislike-circle-sharp" size={28} color="black" /></TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => handleDelete(post.id)}>
              <Text style={{ color: 'red' }}>Delete</Text>
            </TouchableOpacity>
          </View>

        </View>

        <View>
        <View style={{marginTop: 5, marginLeft: 20, marginRight: 20, padding:15, borderBottomWidth: 1, borderColor: COLORS.gray}}>
            <Text style={{ color: COLORS.gray }}>posted 1 min ago</Text>
            <View style={{ flexDirection: 'row' }}>
            <Text style={{ fontSize: 18, fontWeight: '800', maxWidth: '55%', width: '60%' }}>Quantum Forge Solutions</Text>
            <TouchableOpacity style={{ marginLeft: 90 }}><Ionicons name="heart-circle-sharp" size={28} color="black" /></TouchableOpacity>
            <TouchableOpacity><Ionicons name="heart-dislike-circle-sharp" size={28} color="black" /></TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => handleDelete(post.id)}>
              <Text style={{ color: 'red' }}>Delete</Text>
            </TouchableOpacity>
          </View>

        </View>

        <View>
        <View style={{marginTop: 5, marginLeft: 20, marginRight: 20, padding:15, borderBottomWidth: 1, borderColor: COLORS.gray}}>
            <Text style={{ color: COLORS.gray }}>posted 1 min ago</Text>
            <View style={{ flexDirection: 'row' }}>
            <Text style={{ fontSize: 18, fontWeight: '800', maxWidth: '55%', width: '60%' }}>NovaWave Tech Ventures</Text>
            <TouchableOpacity style={{ marginLeft: 90 }}><Ionicons name="heart-circle-sharp" size={28} color="black" /></TouchableOpacity>
            <TouchableOpacity><Ionicons name="heart-dislike-circle-sharp" size={28} color="black" /></TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => handleDelete(post.id)}>
              <Text style={{ color: 'red' }}>Delete</Text>
            </TouchableOpacity>
          </View>

        </View>

        <View>
        <View style={{marginTop: 5, marginLeft: 20, marginRight: 20, padding:15, borderBottomWidth: 1, borderColor: COLORS.gray}}>
            <Text style={{ color: COLORS.gray }}>posted 1 min ago</Text>
            <View style={{ flexDirection: 'row' }}>
            <Text style={{ fontSize: 32, fontWeight: '800', maxWidth: '55%', width: '60%' }}>Zenith Insights Group</Text>
            <TouchableOpacity style={{ marginLeft: 90 }}><Ionicons name="heart-circle-sharp" size={28} color="black" /></TouchableOpacity>
            <TouchableOpacity><Ionicons name="heart-dislike-circle-sharp" size={28} color="black" /></TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => handleDelete(post.id)}>
              <Text style={{ color: 'red' }}>Delete</Text>
            </TouchableOpacity>
          </View>

        </View>

        
      </ScrollView>
    </View>
  );
};

export default App;
