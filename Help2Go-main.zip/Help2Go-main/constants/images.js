const illustration = require('../assets/images/illustration.png')
const cat = require('../assets/images/cat.png')
const down = require('../assets/images/down.png')
const usFlag = require('../assets/images/us-flag.jpg')
const user1 = require('../assets/images/user1.jpg')
const user2 = require('../assets/images/user2.jpg')
const user3 = require('../assets/images/user3.jpg')
const user4 = require('../assets/images/user4.jpg')
const user5 = require('../assets/images/user5.jpg')
const user6 = require('../assets/images/user6.jpg')
const user7 = require('../assets/images/user7.jpg')
const user8 = require('../assets/images/user8.jpg')

export default {
    illustration,
    cat,
    down,
    user1,
    user2,
    user3,
    user4,
    user5,
    user6,
    user7,
    user8,
    usFlag,
}
